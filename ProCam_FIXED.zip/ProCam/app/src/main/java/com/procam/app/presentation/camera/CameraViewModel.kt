package com.procam.app.presentation.camera

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.procam.app.ai.pipeline.AIProcessingPipeline
import com.procam.app.data.repository.ImageRepository
import com.procam.app.data.repository.SettingsRepository
import com.procam.app.domain.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

sealed class ProcessingState {
    object Idle : ProcessingState()
    data class Processing(val message: String) : ProcessingState()
    data class Success(val imagePath: String) : ProcessingState()
    data class Error(val message: String) : ProcessingState()
}

@HiltViewModel
class CameraViewModel @Inject constructor(
    private val aiPipeline: AIProcessingPipeline,
    private val imageRepository: ImageRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _cameraConfig = MutableStateFlow(CameraConfig())
    val cameraConfig: StateFlow<CameraConfig> = _cameraConfig.asStateFlow()

    private val _processingState = MutableStateFlow<ProcessingState>(ProcessingState.Idle)
    val processingState: StateFlow<ProcessingState> = _processingState.asStateFlow()

    private var currentBitmap: Bitmap? = null

    init {
        loadSettings()
    }

    private fun loadSettings() {
        viewModelScope.launch {
            settingsRepository.getAIProcessingConfig().collect { config ->
                Timber.d("Loaded AI config: $config")
            }
        }
    }

    fun processImage(bitmap: Bitmap) {
        currentBitmap = bitmap
        
        viewModelScope.launch {
            try {
                _processingState.value = ProcessingState.Processing("Preparing image...")

                // Get AI processing config
                val aiConfig = settingsRepository.getAIProcessingConfig().first()

                // Run auto-enhancement pipeline
                aiPipeline.autoEnhanceCapture(bitmap, aiConfig).collect { result ->
                    when (result) {
                        is ProcessingResult.Progress -> {
                            _processingState.value = ProcessingState.Processing(result.currentOperation)
                        }
                        is ProcessingResult.Success -> {
                            // Save the enhanced image
                            val savedPath = imageRepository.saveImage(
                                bitmap = bitmap, // This will be the enhanced bitmap
                                saveOriginal = aiConfig.saveOriginal,
                                originalBitmap = if (aiConfig.saveOriginal) currentBitmap else null
                            )
                            
                            _processingState.value = ProcessingState.Success(savedPath)
                            currentBitmap = null
                        }
                        is ProcessingResult.Error -> {
                            _processingState.value = ProcessingState.Error(result.message)
                            currentBitmap = null
                        }
                    }
                }

            } catch (e: Exception) {
                Timber.e(e, "Image processing failed")
                _processingState.value = ProcessingState.Error("Processing failed: ${e.message}")
                currentBitmap = null
            }
        }
    }

    fun toggleFlash() {
        val currentMode = _cameraConfig.value.flashMode
        val newMode = when (currentMode) {
            FlashMode.OFF -> FlashMode.AUTO
            FlashMode.AUTO -> FlashMode.ON
            FlashMode.ON -> FlashMode.OFF
        }
        _cameraConfig.value = _cameraConfig.value.copy(flashMode = newMode)
    }

    fun toggleHDR() {
        _cameraConfig.value = _cameraConfig.value.copy(
            hdrEnabled = !_cameraConfig.value.hdrEnabled
        )
    }

    fun setResolution(resolution: CameraResolution) {
        _cameraConfig.value = _cameraConfig.value.copy(resolution = resolution)
    }

    override fun onCleared() {
        super.onCleared()
        currentBitmap?.recycle()
    }
}
