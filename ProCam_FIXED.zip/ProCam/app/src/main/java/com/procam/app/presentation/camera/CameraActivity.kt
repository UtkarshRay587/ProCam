package com.procam.app.presentation.camera

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.procam.app.R
import com.procam.app.databinding.ActivityCameraBinding
import com.procam.app.domain.model.CameraConfig
import com.procam.app.domain.model.FlashMode
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

@AndroidEntryPoint
class CameraActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCameraBinding
    private val viewModel: CameraViewModel by viewModels()

    private var preview: Preview? = null
    private var imageCapture: ImageCapture? = null
    private var camera: Camera? = null
    private var cameraProvider: ProcessCameraProvider? = null

    private lateinit var cameraExecutor: ExecutorService

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { importImage(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCameraBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraExecutor = Executors.newSingleThreadExecutor()

        setupUI()
        checkPermissionsAndStartCamera()
    }

    private fun setupUI() {
        // Capture button
        binding.captureButton.setOnClickListener {
            takePhoto()
        }

        // Import button
        binding.importButton.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        // Flash toggle
        binding.flashButton.setOnClickListener {
            toggleFlash()
        }

        // HDR toggle
        binding.hdrButton.setOnClickListener {
            toggleHDR()
        }

        // Settings button
        binding.settingsButton.setOnClickListener {
            // Open settings
        }

        // Gallery button
        binding.galleryButton.setOnClickListener {
            finish() // Return to main activity with gallery
        }

        // Observe camera config
        lifecycleScope.launch {
            viewModel.cameraConfig.collect { config ->
                updateFlashUI(config.flashMode)
                updateHDRUI(config.hdrEnabled)
            }
        }

        // Observe processing state
        lifecycleScope.launch {
            viewModel.processingState.collect { state ->
                when (state) {
                    is ProcessingState.Idle -> hideProgress()
                    is ProcessingState.Processing -> showProgress(state.message)
                    is ProcessingState.Success -> {
                        hideProgress()
                        Toast.makeText(this@CameraActivity, "Image saved!", Toast.LENGTH_SHORT).show()
                        finish() // Return to gallery
                    }
                    is ProcessingState.Error -> {
                        hideProgress()
                        Toast.makeText(this@CameraActivity, state.message, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun checkPermissionsAndStartCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_CODE)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startCamera()
            } else {
                Toast.makeText(this, "Camera permission required", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            bindCameraUseCases()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCameraUseCases() {
        val cameraProvider = cameraProvider ?: return

        // Preview
        preview = Preview.Builder()
            .build()
            .also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }

        // Image capture
        imageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .build()

        // Select back camera
        val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

        try {
            // Unbind all use cases before rebinding
            cameraProvider.unbindAll()

            // Bind use cases to camera
            camera = cameraProvider.bindToLifecycle(
                this,
                cameraSelector,
                preview,
                imageCapture
            )

        } catch (e: Exception) {
            Timber.e(e, "Use case binding failed")
        }
    }

    private fun takePhoto() {
        val imageCapture = imageCapture ?: return

        // Create temp file for capture
        val photoFile = File(
            externalCacheDir,
            "temp_capture_${System.currentTimeMillis()}.jpg"
        )

        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        imageCapture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    Timber.d("Photo captured: ${photoFile.absolutePath}")
                    
                    // Load bitmap
                    val bitmap = BitmapFactory.decodeFile(photoFile.absolutePath)
                    val rotatedBitmap = rotateBitmapIfNeeded(bitmap, photoFile.absolutePath)
                    
                    // Send to AI pipeline
                    viewModel.processImage(rotatedBitmap)
                    
                    // Delete temp file
                    photoFile.delete()
                }

                override fun onError(exception: ImageCaptureException) {
                    Timber.e(exception, "Photo capture failed")
                    Toast.makeText(
                        this@CameraActivity,
                        "Failed to capture photo",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        )
    }

    private fun importImage(uri: Uri) {
        try {
            val inputStream = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            if (bitmap != null) {
                viewModel.processImage(bitmap)
            } else {
                Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to import image")
            Toast.makeText(this, "Failed to import image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun rotateBitmapIfNeeded(bitmap: Bitmap, path: String): Bitmap {
        val exif = androidx.exifinterface.media.ExifInterface(path)
        val orientation = exif.getAttributeInt(
            androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,
            androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL
        )

        val matrix = Matrix()
        when (orientation) {
            androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
        }

        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun toggleFlash() {
        viewModel.toggleFlash()
        camera?.cameraControl?.enableTorch(
            viewModel.cameraConfig.value.flashMode == FlashMode.ON
        )
    }

    private fun toggleHDR() {
        viewModel.toggleHDR()
    }

    private fun updateFlashUI(mode: FlashMode) {
        binding.flashButton.setImageResource(
            when (mode) {
                FlashMode.OFF -> R.drawable.ic_flash_off
                FlashMode.ON -> R.drawable.ic_flash_on
                FlashMode.AUTO -> R.drawable.ic_flash_auto
            }
        )
    }

    private fun updateHDRUI(enabled: Boolean) {
        binding.hdrButton.alpha = if (enabled) 1.0f else 0.5f
    }

    private fun showProgress(message: String) {
        binding.progressOverlay.visibility = android.view.View.VISIBLE
        binding.progressText.text = message
    }

    private fun hideProgress() {
        binding.progressOverlay.visibility = android.view.View.GONE
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }

    companion object {
        private const val CAMERA_PERMISSION_CODE = 100
    }
}
