package com.procam.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.procam.app.domain.model.ImageMetadata
import com.procam.app.domain.model.Location
import com.procam.app.domain.model.ProCamImage
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.Date

/**
 * Image entity for Room database
 */
@Entity(tableName = "images")
@TypeConverters(Converters::class)
data class ImageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val filePath: String,
    val fileName: String,
    val dateTaken: Date,
    val dateModified: Date,
    val width: Int,
    val height: Int,
    val size: Long,
    val isProcessed: Boolean = false,
    val hasOriginal: Boolean = false,
    val originalPath: String? = null,
    val metadata: ImageMetadata? = null
) {
    fun toDomainModel(): ProCamImage {
        return ProCamImage(
            id = id,
            filePath = filePath,
            fileName = fileName,
            dateTaken = dateTaken,
            dateModified = dateModified,
            width = width,
            height = height,
            size = size,
            isProcessed = isProcessed,
            hasOriginal = hasOriginal,
            originalPath = originalPath,
            metadata = metadata
        )
    }
}

/**
 * Type converters for Room
 */
class Converters {
    private val gson = Gson()

    @TypeConverter
    fun fromTimestamp(value: Long?): Date? {
        return value?.let { Date(it) }
    }

    @TypeConverter
    fun dateToTimestamp(date: Date?): Long? {
        return date?.time
    }

    @TypeConverter
    fun fromImageMetadata(metadata: ImageMetadata?): String? {
        return metadata?.let { gson.toJson(it) }
    }

    @TypeConverter
    fun toImageMetadata(json: String?): ImageMetadata? {
        return json?.let {
            val type = object : TypeToken<ImageMetadata>() {}.type
            gson.fromJson(it, type)
        }
    }
}
