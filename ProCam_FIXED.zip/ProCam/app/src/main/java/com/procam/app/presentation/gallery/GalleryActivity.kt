package com.procam.app.presentation.gallery

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.procam.app.R
import com.procam.app.databinding.ActivityGalleryBinding
import com.procam.app.domain.model.ProCamImage
import com.procam.app.presentation.camera.CameraActivity
import com.procam.app.presentation.editor.EditorActivity
import com.procam.app.presentation.settings.SettingsActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import timber.log.Timber

@AndroidEntryPoint
class GalleryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGalleryBinding
    private val viewModel: GalleryViewModel by viewModels()
    private lateinit var adapter: GalleryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGalleryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerView()
        setupFAB()
        observeViewModel()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = "ProCam Gallery"
    }

    private fun setupRecyclerView() {
        adapter = GalleryAdapter(
            onImageClick = { image ->
                openEditor(image)
            },
            onImageLongClick = { image ->
                showImageOptions(image)
            }
        )

        binding.recyclerView.apply {
            layoutManager = GridLayoutManager(this@GalleryActivity, 3)
            adapter = this@GalleryActivity.adapter
            setHasFixedSize(true)
        }
    }

    private fun setupFAB() {
        binding.fabCamera.setOnClickListener {
            openCamera()
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.images.collect { images ->
                Timber.d("Gallery images updated: ${images.size} images")
                adapter.submitList(images)
                
                if (images.isEmpty()) {
                    binding.emptyView.visibility = android.view.View.VISIBLE
                    binding.recyclerView.visibility = android.view.View.GONE
                } else {
                    binding.emptyView.visibility = android.view.View.GONE
                    binding.recyclerView.visibility = android.view.View.VISIBLE
                }
            }
        }

        lifecycleScope.launch {
            viewModel.isLoading.collect { isLoading ->
                binding.progressBar.visibility = if (isLoading) {
                    android.view.View.VISIBLE
                } else {
                    android.view.View.GONE
                }
            }
        }
    }

    private fun openCamera() {
        startActivity(Intent(this, CameraActivity::class.java))
    }

    private fun openEditor(image: ProCamImage) {
        val intent = Intent(this, EditorActivity::class.java).apply {
            putExtra(EditorActivity.EXTRA_IMAGE_PATH, image.filePath)
            putExtra(EditorActivity.EXTRA_IMAGE_ID, image.id)
        }
        startActivity(intent)
    }

    private fun showImageOptions(image: ProCamImage) {
        // Show bottom sheet with options: Share, Delete, Export, etc.
        val bottomSheet = ImageOptionsBottomSheet.newInstance(image.id)
        bottomSheet.show(supportFragmentManager, "image_options")
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.gallery_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            R.id.action_sort -> {
                showSortDialog()
                true
            }
            R.id.action_filter -> {
                showFilterDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showSortDialog() {
        // Show dialog to select sort order
        val options = arrayOf(
            "Date (Newest First)",
            "Date (Oldest First)",
            "Name (A-Z)",
            "Name (Z-A)",
            "Size (Largest)",
            "Size (Smallest)"
        )
        
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Sort By")
            .setItems(options) { _, which ->
                viewModel.setSortOrder(which)
            }
            .show()
    }

    private fun showFilterDialog() {
        // Show dialog to filter images
        val options = arrayOf(
            "All Images",
            "Processed Only",
            "With Originals"
        )
        
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Filter")
            .setItems(options) { _, which ->
                viewModel.setFilter(which)
            }
            .show()
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshGallery()
    }
}
