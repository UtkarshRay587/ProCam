package com.procam.app.presentation.main

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.procam.app.R
import com.procam.app.presentation.gallery.GalleryActivity
import dagger.hilt.android.AndroidEntryPoint

/**
 * Main entry point of ProCam
 * Handles permissions and navigation to Gallery
 */
@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private val permissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        
        if (allGranted) {
            navigateToGallery()
        } else {
            showPermissionDeniedDialog()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        checkAndRequestPermissions()
    }

    private fun checkAndRequestPermissions() {
        val requiredPermissions = mutableListOf(
            Manifest.permission.CAMERA
        )

        // Add appropriate storage permissions based on Android version
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requiredPermissions.add(Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            requiredPermissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                requiredPermissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }

        val permissionsToRequest = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (permissionsToRequest.isEmpty()) {
            navigateToGallery()
        } else {
            // Show rationale if needed
            if (permissionsToRequest.any { shouldShowRequestPermissionRationale(it) }) {
                showPermissionRationale(permissionsToRequest)
            } else {
                permissionsLauncher.launch(permissionsToRequest.toTypedArray())
            }
        }
    }

    private fun showPermissionRationale(permissions: List<String>) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Permissions Required")
            .setMessage(
                "ProCam needs the following permissions to work:\n\n" +
                "• Camera: To capture photos\n" +
                "• Storage: To save and manage your photos\n\n" +
                "ProCam is 100% offline and private. Your photos never leave your device."
            )
            .setPositiveButton("Grant Permissions") { _, _ ->
                permissionsLauncher.launch(permissions.toTypedArray())
            }
            .setNegativeButton("Exit") { _, _ ->
                finish()
            }
            .setCancelable(false)
            .show()
    }

    private fun showPermissionDeniedDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Permissions Required")
            .setMessage("ProCam cannot function without the required permissions.")
            .setPositiveButton("Retry") { _, _ ->
                checkAndRequestPermissions()
            }
            .setNegativeButton("Exit") { _, _ ->
                finish()
            }
            .setCancelable(false)
            .show()
    }

    private fun navigateToGallery() {
        val intent = Intent(this, GalleryActivity::class.java)
        startActivity(intent)
        finish()
    }
}
