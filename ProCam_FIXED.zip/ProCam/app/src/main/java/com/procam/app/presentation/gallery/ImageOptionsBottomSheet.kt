package com.procam.app.presentation.gallery

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.fragment.app.viewModels
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.procam.app.BuildConfig
import com.procam.app.databinding.BottomSheetImageOptionsBinding
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber
import java.io.File

@AndroidEntryPoint
class ImageOptionsBottomSheet : BottomSheetDialogFragment() {

    private var _binding: BottomSheetImageOptionsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: GalleryViewModel by viewModels({ requireParentFragment() })
    private var imageId: Long = -1

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return BottomSheetDialog(requireContext(), theme)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomSheetImageOptionsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        imageId = arguments?.getLong(ARG_IMAGE_ID) ?: -1

        setupButtons()
    }

    private fun setupButtons() {
        binding.btnShare.setOnClickListener {
            shareImage()
        }

        binding.btnExport.setOnClickListener {
            exportToGallery()
        }

        binding.btnDuplicate.setOnClickListener {
            duplicateImage()
        }

        binding.btnDelete.setOnClickListener {
            confirmDelete()
        }

        binding.btnViewOriginal.setOnClickListener {
            viewOriginal()
        }

        binding.btnImageInfo.setOnClickListener {
            showImageInfo()
        }
    }

    private fun shareImage() {
        // TODO: Implement sharing via ShareSheet
        Toast.makeText(requireContext(), "Share functionality coming soon", Toast.LENGTH_SHORT).show()
        dismiss()
    }

    private fun exportToGallery() {
        // TODO: Implement MediaStore export
        Toast.makeText(requireContext(), "Export to gallery coming soon", Toast.LENGTH_SHORT).show()
        dismiss()
    }

    private fun duplicateImage() {
        // TODO: Implement duplicate
        Toast.makeText(requireContext(), "Duplicate coming soon", Toast.LENGTH_SHORT).show()
        dismiss()
    }

    private fun confirmDelete() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Delete Image")
            .setMessage("Are you sure you want to delete this image? This cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                deleteImage()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteImage() {
        viewModel.deleteImage(imageId)
        Toast.makeText(requireContext(), "Image deleted", Toast.LENGTH_SHORT).show()
        dismiss()
    }

    private fun viewOriginal() {
        // TODO: If image has original, show it
        Toast.makeText(requireContext(), "Original view coming soon", Toast.LENGTH_SHORT).show()
        dismiss()
    }

    private fun showImageInfo() {
        // TODO: Show image metadata dialog
        Toast.makeText(requireContext(), "Image info coming soon", Toast.LENGTH_SHORT).show()
        dismiss()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val ARG_IMAGE_ID = "image_id"

        fun newInstance(imageId: Long): ImageOptionsBottomSheet {
            return ImageOptionsBottomSheet().apply {
                arguments = Bundle().apply {
                    putLong(ARG_IMAGE_ID, imageId)
                }
            }
        }
    }
}
