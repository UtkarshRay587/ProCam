package com.procam.app.presentation.gallery

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.procam.app.databinding.ItemGalleryImageBinding
import com.procam.app.domain.model.ProCamImage
import java.io.File

/**
 * Gallery Adapter for displaying images in grid
 */
class GalleryAdapter(
    private val onImageClick: (ProCamImage) -> Unit,
    private val onImageLongClick: (ProCamImage) -> Unit
) : ListAdapter<ProCamImage, GalleryAdapter.ImageViewHolder>(ImageDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
        val binding = ItemGalleryImageBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ImageViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ImageViewHolder(
        private val binding: ItemGalleryImageBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(image: ProCamImage) {
            // Load image thumbnail
            binding.imageView.load(File(image.filePath)) {
                crossfade(true)
                placeholder(android.R.drawable.ic_menu_gallery)
                error(android.R.drawable.ic_menu_report_image)
            }

            // Show processed indicator if applicable
            binding.processedIndicator.visibility = if (image.isProcessed) {
                android.view.View.VISIBLE
            } else {
                android.view.View.GONE
            }

            // Click listeners
            binding.root.setOnClickListener {
                onImageClick(image)
            }

            binding.root.setOnLongClickListener {
                onImageLongClick(image)
                true
            }
        }
    }

    class ImageDiffCallback : DiffUtil.ItemCallback<ProCamImage>() {
        override fun areItemsTheSame(oldItem: ProCamImage, newItem: ProCamImage): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: ProCamImage, newItem: ProCamImage): Boolean {
            return oldItem == newItem
        }
    }
}
