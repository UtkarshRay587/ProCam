package com.procam.app.di

import android.content.Context
import com.procam.app.data.local.ProCamDatabase
import com.procam.app.data.local.dao.ImageDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Database Module
 * Provides database and DAOs
 */
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): ProCamDatabase {
        return ProCamDatabase.getDatabase(context)
    }

    @Provides
    @Singleton
    fun provideImageDao(database: ProCamDatabase): ImageDao {
        return database.imageDao()
    }
}

/**
 * App Module
 * Provides app-level dependencies
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideContext(@ApplicationContext context: Context): Context {
        return context
    }
}
