package com.procam.app.ai.pipeline

import android.content.Context
import android.graphics.Bitmap
import com.procam.app.ai.processors.*
import com.procam.app.domain.model.*
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Core AI Processing Pipeline
 * Orchestrates all AI enhancement operations
 */
@Singleton
class AIProcessingPipeline @Inject constructor(
    @ApplicationContext private val context: Context,
    private val preProcessor: ImagePreProcessor,
    private val autoEnhancer: AutoEnhanceProcessor,
    private val denoiseProcessor: DenoiseProcessor,
    private val sharpenProcessor: SharpenProcessor,
    private val superResProcessor: SuperResolutionProcessor,
    private val lowLightProcessor: LowLightBoostProcessor,
    private val detailRecoveryProcessor: DetailRecoveryProcessor,
    private val backgroundRemover: BackgroundRemovalProcessor,
    private val objectRemover: ObjectRemovalProcessor,
    private val postProcessor: ImagePostProcessor
) {

    /**
     * Auto-enhance pipeline for camera captures
     * This runs automatically after taking a photo
     */
    suspend fun autoEnhanceCapture(
        bitmap: Bitmap,
        config: AIProcessingConfig
    ): Flow<ProcessingResult> = flow {
        try {
            emit(ProcessingResult.Progress(0, "Starting enhancement..."))
            
            // Step 1: Pre-processing
            emit(ProcessingResult.Progress(10, "Pre-processing image..."))
            val preprocessed = withContext(Dispatchers.Default) {
                preProcessor.process(bitmap, config.processingQuality)
            }
            
            // Step 2: Auto Enhancement (if enabled)
            val enhanced = if (config.autoEnhance) {
                emit(ProcessingResult.Progress(30, "AI auto-enhancing..."))
                withContext(Dispatchers.Default) {
                    autoEnhancer.enhance(preprocessed, config)
                }
            } else {
                preprocessed
            }
            
            // Step 3: Denoise (if strength > 0)
            val denoised = if (config.denoiseStrength > 0) {
                emit(ProcessingResult.Progress(50, "Reducing noise..."))
                withContext(Dispatchers.Default) {
                    denoiseProcessor.denoise(enhanced, config.denoiseStrength, config)
                }
            } else {
                enhanced
            }
            
            // Step 4: Sharpen (if strength > 0)
            val sharpened = if (config.sharpenStrength > 0) {
                emit(ProcessingResult.Progress(70, "Sharpening details..."))
                withContext(Dispatchers.Default) {
                    sharpenProcessor.sharpen(denoised, config.sharpenStrength, config)
                }
            } else {
                denoised
            }
            
            // Step 5: Post-processing
            emit(ProcessingResult.Progress(90, "Finalizing..."))
            val final = withContext(Dispatchers.Default) {
                postProcessor.process(sharpened, config)
            }
            
            emit(ProcessingResult.Progress(100, "Complete!"))
            
            // Return success with bitmap (caller will save it)
            emit(ProcessingResult.Success(
                outputPath = "", // Will be set by caller after saving
                processingTime = 0L,
                operations = listOf(
                    EditOperation.AIAutoEnhance(100),
                    EditOperation.AIDenoise(config.denoiseStrength),
                    EditOperation.AISharpen(config.sharpenStrength)
                )
            ))
            
        } catch (e: Exception) {
            Timber.e(e, "Auto-enhance pipeline failed")
            emit(ProcessingResult.Error("Enhancement failed: ${e.message}", e))
        }
    }

    /**
     * Process a single edit operation
     */
    suspend fun processOperation(
        bitmap: Bitmap,
        operation: EditOperation,
        config: AIProcessingConfig
    ): Bitmap = withContext(Dispatchers.Default) {
        Timber.d("Processing operation: $operation")
        
        when (operation) {
            is EditOperation.AIAutoEnhance -> 
                autoEnhancer.enhance(bitmap, config)
            
            is EditOperation.AIDenoise -> 
                denoiseProcessor.denoise(bitmap, operation.strength, config)
            
            is EditOperation.AISharpen -> 
                sharpenProcessor.sharpen(bitmap, operation.strength, config)
            
            is EditOperation.AISuperResolution -> 
                superResProcessor.upscale(bitmap, operation.scale, config)
            
            is EditOperation.AILowLightBoost -> 
                lowLightProcessor.boost(bitmap, operation.strength, config)
            
            is EditOperation.AIDetailRecovery -> 
                detailRecoveryProcessor.recover(bitmap, operation.strength, config)
            
            is EditOperation.AIBackgroundRemoval -> 
                backgroundRemover.removeBackground(bitmap, operation.keepTransparent)
            
            is EditOperation.AIObjectRemoval -> 
                objectRemover.removeObject(bitmap, operation.maskPath)
            
            is EditOperation.Brightness -> 
                applyBrightness(bitmap, operation.value)
            
            is EditOperation.Contrast -> 
                applyContrast(bitmap, operation.value)
            
            is EditOperation.Highlights -> 
                applyHighlights(bitmap, operation.value)
            
            is EditOperation.Shadows -> 
                applyShadows(bitmap, operation.value)
            
            is EditOperation.Saturation -> 
                applySaturation(bitmap, operation.value)
            
            is EditOperation.Temperature -> 
                applyTemperature(bitmap, operation.value)
            
            is EditOperation.Tint -> 
                applyTint(bitmap, operation.value)
            
            is EditOperation.Clarity -> 
                applyClarity(bitmap, operation.value)
        }
    }

    /**
     * Process multiple operations in sequence
     */
    suspend fun processOperations(
        bitmap: Bitmap,
        operations: List<EditOperation>,
        config: AIProcessingConfig
    ): Flow<ProcessingResult> = flow {
        try {
            var currentBitmap = bitmap
            val totalOps = operations.size
            
            operations.forEachIndexed { index, operation ->
                val progress = ((index + 1) * 100) / totalOps
                emit(ProcessingResult.Progress(progress, "Processing: ${operation::class.simpleName}"))
                
                currentBitmap = processOperation(currentBitmap, operation, config)
            }
            
            emit(ProcessingResult.Success(
                outputPath = "",
                processingTime = 0L,
                operations = operations
            ))
            
        } catch (e: Exception) {
            Timber.e(e, "Batch processing failed")
            emit(ProcessingResult.Error("Processing failed: ${e.message}", e))
        }
    }

    // Classic adjustment implementations using ColorMatrix
    
    private fun applyBrightness(bitmap: Bitmap, value: Int): Bitmap {
        // -100 to 100 -> apply brightness adjustment
        return ImageAdjustments.adjustBrightness(bitmap, value / 100f)
    }

    private fun applyContrast(bitmap: Bitmap, value: Int): Bitmap {
        return ImageAdjustments.adjustContrast(bitmap, 1f + (value / 100f))
    }

    private fun applyHighlights(bitmap: Bitmap, value: Int): Bitmap {
        return ImageAdjustments.adjustHighlights(bitmap, value / 100f)
    }

    private fun applyShadows(bitmap: Bitmap, value: Int): Bitmap {
        return ImageAdjustments.adjustShadows(bitmap, value / 100f)
    }

    private fun applySaturation(bitmap: Bitmap, value: Int): Bitmap {
        return ImageAdjustments.adjustSaturation(bitmap, 1f + (value / 100f))
    }

    private fun applyTemperature(bitmap: Bitmap, value: Int): Bitmap {
        return ImageAdjustments.adjustTemperature(bitmap, value / 100f)
    }

    private fun applyTint(bitmap: Bitmap, value: Int): Bitmap {
        return ImageAdjustments.adjustTint(bitmap, value / 100f)
    }

    private fun applyClarity(bitmap: Bitmap, value: Int): Bitmap {
        return ImageAdjustments.adjustClarity(bitmap, value / 100f)
    }
}
