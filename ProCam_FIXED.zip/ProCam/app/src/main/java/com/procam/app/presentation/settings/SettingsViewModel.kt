package com.procam.app.presentation.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.procam.app.data.repository.SettingsRepository
import com.procam.app.domain.model.AIProcessingConfig
import com.procam.app.domain.model.ProcessingQuality
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    val config: StateFlow<AIProcessingConfig> = settingsRepository.getAIProcessingConfig()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AIProcessingConfig()
        )

    fun setAutoEnhanceEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setAutoEnhanceEnabled(enabled)
        }
    }

    fun setDenoiseStrength(strength: Int) {
        viewModelScope.launch {
            settingsRepository.setDenoiseStrength(strength)
        }
    }

    fun setSharpenStrength(strength: Int) {
        viewModelScope.launch {
            settingsRepository.setSharpenStrength(strength)
        }
    }

    fun setPreserveSkin(preserve: Boolean) {
        viewModelScope.launch {
            settingsRepository.setPreserveSkin(preserve)
        }
    }

    fun setPreserveTexture(preserve: Boolean) {
        viewModelScope.launch {
            settingsRepository.setPreserveTexture(preserve)
        }
    }

    fun setProcessingQuality(quality: ProcessingQuality) {
        viewModelScope.launch {
            settingsRepository.setProcessingQuality(quality)
        }
    }

    fun setSaveOriginal(save: Boolean) {
        viewModelScope.launch {
            settingsRepository.setSaveOriginal(save)
        }
    }

    fun setAutoExport(export: Boolean) {
        viewModelScope.launch {
            settingsRepository.setAutoExportToGallery(export)
        }
    }

    fun resetToDefaults() {
        viewModelScope.launch {
            settingsRepository.resetToDefaults()
        }
    }
}
