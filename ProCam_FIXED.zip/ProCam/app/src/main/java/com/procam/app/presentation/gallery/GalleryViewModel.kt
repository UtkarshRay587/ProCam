package com.procam.app.presentation.gallery

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.procam.app.data.repository.ImageRepository
import com.procam.app.domain.model.GalleryFilter
import com.procam.app.domain.model.ProCamImage
import com.procam.app.domain.model.SortBy
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

@HiltViewModel
class GalleryViewModel @Inject constructor(
    private val imageRepository: ImageRepository
) : ViewModel() {

    private val _images = MutableStateFlow<List<ProCamImage>>(emptyList())
    val images: StateFlow<List<ProCamImage>> = _images.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _currentFilter = MutableStateFlow(GalleryFilter())
    val currentFilter: StateFlow<GalleryFilter> = _currentFilter.asStateFlow()

    init {
        loadImages()
    }

    fun refreshGallery() {
        loadImages()
    }

    private fun loadImages() {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                
                imageRepository.getAllImages()
                    .combine(_currentFilter) { images, filter ->
                        applyFilter(images, filter)
                    }
                    .collect { filteredImages ->
                        _images.value = filteredImages
                        _isLoading.value = false
                    }
                    
            } catch (e: Exception) {
                Timber.e(e, "Failed to load images")
                _isLoading.value = false
            }
        }
    }

    private fun applyFilter(images: List<ProCamImage>, filter: GalleryFilter): List<ProCamImage> {
        var filtered = images

        // Apply processed only filter
        if (filter.showProcessedOnly) {
            filtered = filtered.filter { it.isProcessed }
        }

        // Apply sorting
        filtered = when (filter.sortBy) {
            SortBy.DATE_DESC -> filtered.sortedByDescending { it.dateTaken }
            SortBy.DATE_ASC -> filtered.sortedBy { it.dateTaken }
            SortBy.NAME_ASC -> filtered.sortedBy { it.fileName }
            SortBy.NAME_DESC -> filtered.sortedByDescending { it.fileName }
            SortBy.SIZE_DESC -> filtered.sortedByDescending { it.size }
            SortBy.SIZE_ASC -> filtered.sortedBy { it.size }
        }

        return filtered
    }

    fun setSortOrder(index: Int) {
        val sortBy = when (index) {
            0 -> SortBy.DATE_DESC
            1 -> SortBy.DATE_ASC
            2 -> SortBy.NAME_ASC
            3 -> SortBy.NAME_DESC
            4 -> SortBy.SIZE_DESC
            5 -> SortBy.SIZE_ASC
            else -> SortBy.DATE_DESC
        }
        
        _currentFilter.value = _currentFilter.value.copy(sortBy = sortBy)
    }

    fun setFilter(index: Int) {
        val showProcessedOnly = index == 1
        _currentFilter.value = _currentFilter.value.copy(showProcessedOnly = showProcessedOnly)
    }

    fun deleteImage(imageId: Long) {
        viewModelScope.launch {
            try {
                imageRepository.deleteImage(imageId)
                refreshGallery()
            } catch (e: Exception) {
                Timber.e(e, "Failed to delete image")
            }
        }
    }
}
