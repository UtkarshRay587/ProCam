package com.procam.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

/**
 * ProCam Application Class
 * Initializes Hilt, Timber, and global configurations
 */
@HiltAndroidApp
class ProCamApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        
        // Initialize logging
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
        
        // Initialize app directories
        initializeAppDirectories()
        
        Timber.d("ProCam Application initialized")
    }

    private fun initializeAppDirectories() {
        // Create ProCam directories
        val procamDir = getExternalFilesDir(null)?.resolve("ProCam")
        val galleryDir = procamDir?.resolve("Gallery")
        val tempDir = procamDir?.resolve("Temp")
        val modelsDir = procamDir?.resolve("Models")

        galleryDir?.mkdirs()
        tempDir?.mkdirs()
        modelsDir?.mkdirs()

        Timber.d("App directories initialized: $procamDir")
    }
}
