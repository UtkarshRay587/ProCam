package com.procam.app.presentation.editor

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.slider.Slider
import com.procam.app.R
import com.procam.app.databinding.ActivityEditorBinding
import com.procam.app.databinding.BottomSheetEditToolBinding
import com.procam.app.domain.model.EditOperation
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import timber.log.Timber

@AndroidEntryPoint
class EditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditorBinding
    private val viewModel: EditorViewModel by viewModels()
    
    private var currentBitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        loadImage()
        setupTools()
        observeViewModel()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "AI Editor"
    }

    private fun loadImage() {
        val imagePath = intent.getStringExtra(EXTRA_IMAGE_PATH)
        val imageId = intent.getLongExtra(EXTRA_IMAGE_ID, -1)

        if (imagePath != null) {
            viewModel.loadImage(imagePath)
        } else {
            Toast.makeText(this, "Error loading image", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun setupTools() {
        // AI Tools Section
        binding.btnAutoEnhance.setOnClickListener {
            showToolSheet("AI Auto Enhance") { strength ->
                viewModel.applyOperation(EditOperation.AIAutoEnhance(strength))
            }
        }

        binding.btnDenoise.setOnClickListener {
            showToolSheet("AI Denoise") { strength ->
                viewModel.applyOperation(EditOperation.AIDenoise(strength))
            }
        }

        binding.btnSharpen.setOnClickListener {
            showToolSheet("AI Sharpen") { strength ->
                viewModel.applyOperation(EditOperation.AISharpen(strength))
            }
        }

        binding.btnSuperRes.setOnClickListener {
            showConfirmDialog("Super Resolution", "Upscale image by 2x?") {
                viewModel.applyOperation(EditOperation.AISuperResolution(2f))
            }
        }

        binding.btnLowLight.setOnClickListener {
            showToolSheet("Low Light Boost") { strength ->
                viewModel.applyOperation(EditOperation.AILowLightBoost(strength))
            }
        }

        binding.btnDetailRecovery.setOnClickListener {
            showToolSheet("Detail Recovery") { strength ->
                viewModel.applyOperation(EditOperation.AIDetailRecovery(strength))
            }
        }

        binding.btnBackgroundRemove.setOnClickListener {
            showBackgroundRemovalDialog()
        }

        binding.btnObjectRemove.setOnClickListener {
            // Enter object removal mode
            Toast.makeText(this, "Draw on areas to remove", Toast.LENGTH_SHORT).show()
            // TODO: Implement drawing UI
        }

        // Classic Adjustments
        binding.btnBrightness.setOnClickListener {
            showAdjustmentSheet("Brightness", -100, 100) { value ->
                viewModel.applyOperation(EditOperation.Brightness(value))
            }
        }

        binding.btnContrast.setOnClickListener {
            showAdjustmentSheet("Contrast", -100, 100) { value ->
                viewModel.applyOperation(EditOperation.Contrast(value))
            }
        }

        binding.btnHighlights.setOnClickListener {
            showAdjustmentSheet("Highlights", -100, 100) { value ->
                viewModel.applyOperation(EditOperation.Highlights(value))
            }
        }

        binding.btnShadows.setOnClickListener {
            showAdjustmentSheet("Shadows", -100, 100) { value ->
                viewModel.applyOperation(EditOperation.Shadows(value))
            }
        }

        binding.btnSaturation.setOnClickListener {
            showAdjustmentSheet("Saturation", -100, 100) { value ->
                viewModel.applyOperation(EditOperation.Saturation(value))
            }
        }

        binding.btnTemperature.setOnClickListener {
            showAdjustmentSheet("Temperature", -100, 100) { value ->
                viewModel.applyOperation(EditOperation.Temperature(value))
            }
        }

        binding.btnTint.setOnClickListener {
            showAdjustmentSheet("Tint", -100, 100) { value ->
                viewModel.applyOperation(EditOperation.Tint(value))
            }
        }

        binding.btnClarity.setOnClickListener {
            showAdjustmentSheet("Clarity", 0, 100) { value ->
                viewModel.applyOperation(EditOperation.Clarity(value))
            }
        }

        // Action Buttons
        binding.btnUndo.setOnClickListener {
            viewModel.undo()
        }

        binding.btnRedo.setOnClickListener {
            viewModel.redo()
        }

        binding.btnReset.setOnClickListener {
            showConfirmDialog("Reset", "Reset all edits?") {
                viewModel.resetToOriginal()
            }
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.currentImage.collect { bitmap ->
                bitmap?.let {
                    binding.imageView.setImageBitmap(it)
                    currentBitmap = it
                }
            }
        }

        lifecycleScope.launch {
            viewModel.canUndo.collect { canUndo ->
                binding.btnUndo.isEnabled = canUndo
                binding.btnUndo.alpha = if (canUndo) 1.0f else 0.5f
            }
        }

        lifecycleScope.launch {
            viewModel.canRedo.collect { canRedo ->
                binding.btnRedo.isEnabled = canRedo
                binding.btnRedo.alpha = if (canRedo) 1.0f else 0.5f
            }
        }

        lifecycleScope.launch {
            viewModel.isProcessing.collect { isProcessing ->
                if (isProcessing) {
                    binding.progressOverlay.visibility = android.view.View.VISIBLE
                } else {
                    binding.progressOverlay.visibility = android.view.View.GONE
                }
            }
        }

        lifecycleScope.launch {
            viewModel.processingProgress.collect { progress ->
                binding.progressText.text = progress.currentOperation
                binding.progressBar.progress = progress.percentage
            }
        }

        lifecycleScope.launch {
            viewModel.errorMessage.collect { error ->
                error?.let {
                    Toast.makeText(this@EditorActivity, it, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showToolSheet(title: String, onApply: (Int) -> Unit) {
        val bottomSheet = BottomSheetDialog(this)
        val sheetBinding = BottomSheetEditToolBinding.inflate(layoutInflater)
        
        sheetBinding.toolTitle.text = title
        sheetBinding.strengthSlider.value = 50f
        sheetBinding.strengthValue.text = "50"
        
        sheetBinding.strengthSlider.addOnChangeListener { _, value, _ ->
            sheetBinding.strengthValue.text = value.toInt().toString()
        }
        
        // Micro settings toggles
        sheetBinding.preserveSkinCheckbox.setOnCheckedChangeListener { _, isChecked ->
            // Update config
        }
        
        sheetBinding.preserveTextureCheckbox.setOnCheckedChangeListener { _, isChecked ->
            // Update config
        }
        
        sheetBinding.applyButton.setOnClickListener {
            val strength = sheetBinding.strengthSlider.value.toInt()
            onApply(strength)
            bottomSheet.dismiss()
        }
        
        sheetBinding.cancelButton.setOnClickListener {
            bottomSheet.dismiss()
        }
        
        bottomSheet.setContentView(sheetBinding.root)
        bottomSheet.show()
    }

    private fun showAdjustmentSheet(title: String, min: Int, max: Int, onApply: (Int) -> Unit) {
        val bottomSheet = BottomSheetDialog(this)
        val sheetBinding = BottomSheetEditToolBinding.inflate(layoutInflater)
        
        sheetBinding.toolTitle.text = title
        sheetBinding.strengthSlider.valueFrom = min.toFloat()
        sheetBinding.strengthSlider.valueTo = max.toFloat()
        sheetBinding.strengthSlider.value = 0f
        sheetBinding.strengthValue.text = "0"
        
        // Hide micro settings for classic adjustments
        sheetBinding.microSettingsGroup.visibility = android.view.View.GONE
        
        sheetBinding.strengthSlider.addOnChangeListener { _, value, _ ->
            sheetBinding.strengthValue.text = value.toInt().toString()
            // Live preview
            onApply(value.toInt())
        }
        
        sheetBinding.applyButton.setOnClickListener {
            bottomSheet.dismiss()
        }
        
        sheetBinding.cancelButton.setOnClickListener {
            viewModel.undo() // Cancel live preview
            bottomSheet.dismiss()
        }
        
        bottomSheet.setContentView(sheetBinding.root)
        bottomSheet.show()
    }

    private fun showBackgroundRemovalDialog() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Background Removal")
            .setMessage("Remove background and make transparent?")
            .setPositiveButton("Transparent") { _, _ ->
                viewModel.applyOperation(EditOperation.AIBackgroundRemoval(true))
            }
            .setNegativeButton("White Background") { _, _ ->
                viewModel.applyOperation(EditOperation.AIBackgroundRemoval(false))
            }
            .setNeutralButton("Cancel", null)
            .show()
    }

    private fun showConfirmDialog(title: String, message: String, onConfirm: () -> Unit) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Yes") { _, _ -> onConfirm() }
            .setNegativeButton("No", null)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.editor_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            R.id.action_save -> {
                saveImage()
                true
            }
            R.id.action_save_copy -> {
                saveAsCopy()
                true
            }
            R.id.action_share -> {
                shareImage()
                true
            }
            R.id.action_export_settings -> {
                showExportSettings()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun saveImage() {
        lifecycleScope.launch {
            try {
                viewModel.saveImage(replaceOriginal = true)
                Toast.makeText(this@EditorActivity, "Image saved!", Toast.LENGTH_SHORT).show()
                finish()
            } catch (e: Exception) {
                Toast.makeText(this@EditorActivity, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun saveAsCopy() {
        lifecycleScope.launch {
            try {
                viewModel.saveImage(replaceOriginal = false)
                Toast.makeText(this@EditorActivity, "Copy saved!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@EditorActivity, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun shareImage() {
        // TODO: Implement sharing
        Toast.makeText(this, "Share functionality coming soon", Toast.LENGTH_SHORT).show()
    }

    private fun showExportSettings() {
        // TODO: Show export settings dialog (format, quality, EXIF, etc.)
        Toast.makeText(this, "Export settings coming soon", Toast.LENGTH_SHORT).show()
    }

    override fun onBackPressed() {
        if (viewModel.hasUnsavedChanges.value) {
            showConfirmDialog("Unsaved Changes", "Discard changes?") {
                super.onBackPressed()
            }
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        currentBitmap?.recycle()
    }

    companion object {
        const val EXTRA_IMAGE_PATH = "extra_image_path"
        const val EXTRA_IMAGE_ID = "extra_image_id"
    }
}
