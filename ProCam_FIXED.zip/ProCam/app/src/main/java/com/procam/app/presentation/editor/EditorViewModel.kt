package com.procam.app.presentation.editor

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.procam.app.ai.pipeline.AIProcessingPipeline
import com.procam.app.data.repository.ImageRepository
import com.procam.app.data.repository.SettingsRepository
import com.procam.app.domain.model.EditOperation
import com.procam.app.domain.model.ProcessingResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import java.util.*
import javax.inject.Inject

data class ProcessingProgress(
    val percentage: Int = 0,
    val currentOperation: String = ""
)

@HiltViewModel
class EditorViewModel @Inject constructor(
    private val aiPipeline: AIProcessingPipeline,
    private val imageRepository: ImageRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _currentImage = MutableStateFlow<Bitmap?>(null)
    val currentImage: StateFlow<Bitmap?> = _currentImage.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _processingProgress = MutableStateFlow(ProcessingProgress())
    val processingProgress: StateFlow<ProcessingProgress> = _processingProgress.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()

    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    private val _hasUnsavedChanges = MutableStateFlow(false)
    val hasUnsavedChanges: StateFlow<Boolean> = _hasUnsavedChanges.asStateFlow()

    // Undo/Redo stacks
    private val undoStack = Stack<Bitmap>()
    private val redoStack = Stack<Bitmap>()
    
    private var originalBitmap: Bitmap? = null
    private var currentImagePath: String? = null

    fun loadImage(path: String) {
        viewModelScope.launch {
            try {
                currentImagePath = path
                val bitmap = BitmapFactory.decodeFile(path)
                
                if (bitmap != null) {
                    originalBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)
                    _currentImage.value = bitmap
                    
                    // Clear stacks on new image
                    undoStack.clear()
                    redoStack.clear()
                    updateUndoRedoState()
                    
                    Timber.d("Image loaded: $path")
                } else {
                    _errorMessage.value = "Failed to load image"
                }
            } catch (e: Exception) {
                Timber.e(e, "Error loading image")
                _errorMessage.value = "Error loading image: ${e.message}"
            }
        }
    }

    fun applyOperation(operation: EditOperation) {
        val current = _currentImage.value ?: return
        
        viewModelScope.launch {
            try {
                _isProcessing.value = true
                _errorMessage.value = null
                
                // Save current state to undo stack
                undoStack.push(current.copy(Bitmap.Config.ARGB_8888, true))
                redoStack.clear() // Clear redo on new operation
                
                // Get AI config
                val config = settingsRepository.getAIProcessingConfig().first()
                
                // Process operation
                val result = aiPipeline.processOperation(current, operation, config)
                
                _currentImage.value = result
                _hasUnsavedChanges.value = true
                updateUndoRedoState()
                
                _isProcessing.value = false
                
                Timber.d("Operation applied: ${operation::class.simpleName}")
                
            } catch (e: Exception) {
                Timber.e(e, "Operation failed")
                _errorMessage.value = "Operation failed: ${e.message}"
                _isProcessing.value = false
                
                // Restore from undo stack on error
                if (undoStack.isNotEmpty()) {
                    _currentImage.value = undoStack.pop()
                    updateUndoRedoState()
                }
            }
        }
    }

    fun applyMultipleOperations(operations: List<EditOperation>) {
        val current = _currentImage.value ?: return
        
        viewModelScope.launch {
            try {
                _isProcessing.value = true
                _errorMessage.value = null
                
                // Save current state
                undoStack.push(current.copy(Bitmap.Config.ARGB_8888, true))
                redoStack.clear()
                
                // Get AI config
                val config = settingsRepository.getAIProcessingConfig().first()
                
                // Process all operations
                aiPipeline.processOperations(current, operations, config).collect { result ->
                    when (result) {
                        is ProcessingResult.Progress -> {
                            _processingProgress.value = ProcessingProgress(
                                result.percentage,
                                result.currentOperation
                            )
                        }
                        is ProcessingResult.Success -> {
                            // Final result will be in the pipeline
                            _hasUnsavedChanges.value = true
                            updateUndoRedoState()
                            _isProcessing.value = false
                        }
                        is ProcessingResult.Error -> {
                            _errorMessage.value = result.message
                            _isProcessing.value = false
                        }
                    }
                }
                
            } catch (e: Exception) {
                Timber.e(e, "Batch operation failed")
                _errorMessage.value = "Batch processing failed: ${e.message}"
                _isProcessing.value = false
            }
        }
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        
        val current = _currentImage.value ?: return
        
        // Move current to redo stack
        redoStack.push(current)
        
        // Pop from undo stack
        _currentImage.value = undoStack.pop()
        
        updateUndoRedoState()
        _hasUnsavedChanges.value = undoStack.isNotEmpty()
        
        Timber.d("Undo performed")
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        
        val current = _currentImage.value ?: return
        
        // Move current to undo stack
        undoStack.push(current)
        
        // Pop from redo stack
        _currentImage.value = redoStack.pop()
        
        updateUndoRedoState()
        _hasUnsavedChanges.value = true
        
        Timber.d("Redo performed")
    }

    fun resetToOriginal() {
        val original = originalBitmap ?: return
        
        val current = _currentImage.value
        if (current != null) {
            undoStack.push(current)
        }
        
        _currentImage.value = original.copy(Bitmap.Config.ARGB_8888, true)
        redoStack.clear()
        updateUndoRedoState()
        _hasUnsavedChanges.value = false
        
        Timber.d("Reset to original")
    }

    private fun updateUndoRedoState() {
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = redoStack.isNotEmpty()
    }

    suspend fun saveImage(replaceOriginal: Boolean) {
        val bitmap = _currentImage.value ?: throw IllegalStateException("No image to save")
        val path = currentImagePath ?: throw IllegalStateException("No image path")
        
        try {
            if (replaceOriginal) {
                // Save over original file
                imageRepository.updateImage(path, bitmap)
                _hasUnsavedChanges.value = false
                Timber.d("Image saved (replaced original)")
            } else {
                // Save as new copy
                val newPath = imageRepository.saveImageCopy(bitmap, path)
                Timber.d("Image saved as copy: $newPath")
            }
        } catch (e: Exception) {
            Timber.e(e, "Save failed")
            throw e
        }
    }

    override fun onCleared() {
        super.onCleared()
        
        // Clean up bitmaps
        _currentImage.value?.recycle()
        originalBitmap?.recycle()
        undoStack.forEach { it.recycle() }
        redoStack.forEach { it.recycle() }
        
        undoStack.clear()
        redoStack.clear()
    }
}
