package com.procam.app.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.procam.app.domain.model.AIProcessingConfig
import com.procam.app.domain.model.ProcessingQuality
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "procam_settings")

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private val dataStore = context.dataStore

    // Preference keys
    private object PreferencesKeys {
        val AUTO_ENHANCE_ENABLED = booleanPreferencesKey("auto_enhance_enabled")
        val DENOISE_STRENGTH = intPreferencesKey("denoise_strength")
        val SHARPEN_STRENGTH = intPreferencesKey("sharpen_strength")
        val PRESERVE_SKIN = booleanPreferencesKey("preserve_skin")
        val PRESERVE_TEXTURE = booleanPreferencesKey("preserve_texture")
        val PROCESSING_QUALITY = stringPreferencesKey("processing_quality")
        val SAVE_ORIGINAL = booleanPreferencesKey("save_original")
        val AUTO_EXPORT_TO_GALLERY = booleanPreferencesKey("auto_export_to_gallery")
        val STORAGE_DIRECTORY = stringPreferencesKey("storage_directory")
    }

    /**
     * Get AI processing configuration
     */
    fun getAIProcessingConfig(): Flow<AIProcessingConfig> {
        return dataStore.data.map { preferences ->
            AIProcessingConfig(
                autoEnhance = preferences[PreferencesKeys.AUTO_ENHANCE_ENABLED] ?: true,
                denoiseStrength = preferences[PreferencesKeys.DENOISE_STRENGTH] ?: 50,
                sharpenStrength = preferences[PreferencesKeys.SHARPEN_STRENGTH] ?: 50,
                preserveSkin = preferences[PreferencesKeys.PRESERVE_SKIN] ?: true,
                preserveTexture = preferences[PreferencesKeys.PRESERVE_TEXTURE] ?: true,
                processingQuality = ProcessingQuality.valueOf(
                    preferences[PreferencesKeys.PROCESSING_QUALITY] ?: ProcessingQuality.BALANCED.name
                ),
                saveOriginal = preferences[PreferencesKeys.SAVE_ORIGINAL] ?: false
            )
        }
    }

    /**
     * Update AI processing configuration
     */
    suspend fun updateAIProcessingConfig(config: AIProcessingConfig) {
        dataStore.edit { preferences ->
            preferences[PreferencesKeys.AUTO_ENHANCE_ENABLED] = config.autoEnhance
            preferences[PreferencesKeys.DENOISE_STRENGTH] = config.denoiseStrength
            preferences[PreferencesKeys.SHARPEN_STRENGTH] = config.sharpenStrength
            preferences[PreferencesKeys.PRESERVE_SKIN] = config.preserveSkin
            preferences[PreferencesKeys.PRESERVE_TEXTURE] = config.preserveTexture
            preferences[PreferencesKeys.PROCESSING_QUALITY] = config.processingQuality.name
            preferences[PreferencesKeys.SAVE_ORIGINAL] = config.saveOriginal
        }
    }

    /**
     * Individual setting updates
     */
    suspend fun setAutoEnhanceEnabled(enabled: Boolean) {
        dataStore.edit { it[PreferencesKeys.AUTO_ENHANCE_ENABLED] = enabled }
    }

    suspend fun setDenoiseStrength(strength: Int) {
        dataStore.edit { it[PreferencesKeys.DENOISE_STRENGTH] = strength }
    }

    suspend fun setSharpenStrength(strength: Int) {
        dataStore.edit { it[PreferencesKeys.SHARPEN_STRENGTH] = strength }
    }

    suspend fun setPreserveSkin(preserve: Boolean) {
        dataStore.edit { it[PreferencesKeys.PRESERVE_SKIN] = preserve }
    }

    suspend fun setPreserveTexture(preserve: Boolean) {
        dataStore.edit { it[PreferencesKeys.PRESERVE_TEXTURE] = preserve }
    }

    suspend fun setProcessingQuality(quality: ProcessingQuality) {
        dataStore.edit { it[PreferencesKeys.PROCESSING_QUALITY] = quality.name }
    }

    suspend fun setSaveOriginal(save: Boolean) {
        dataStore.edit { it[PreferencesKeys.SAVE_ORIGINAL] = save }
    }

    suspend fun setAutoExportToGallery(export: Boolean) {
        dataStore.edit { it[PreferencesKeys.AUTO_EXPORT_TO_GALLERY] = export }
    }

    /**
     * Get individual settings
     */
    fun getAutoExportToGallery(): Flow<Boolean> {
        return dataStore.data.map { it[PreferencesKeys.AUTO_EXPORT_TO_GALLERY] ?: false }
    }

    fun getSaveOriginal(): Flow<Boolean> {
        return dataStore.data.map { it[PreferencesKeys.SAVE_ORIGINAL] ?: false }
    }

    fun getProcessingQuality(): Flow<ProcessingQuality> {
        return dataStore.data.map { 
            ProcessingQuality.valueOf(it[PreferencesKeys.PROCESSING_QUALITY] ?: ProcessingQuality.BALANCED.name)
        }
    }

    /**
     * Reset to defaults
     */
    suspend fun resetToDefaults() {
        dataStore.edit { preferences ->
            preferences.clear()
        }
    }
}
