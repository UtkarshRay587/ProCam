package com.procam.app.ai.processors

import android.graphics.Bitmap
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Canvas
import com.procam.app.domain.model.AIProcessingConfig
import com.procam.app.domain.model.ProcessingQuality
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Image Pre-processor
 * Normalizes and prepares images for AI processing
 */
@Singleton
class ImagePreProcessor @Inject constructor() {

    fun process(bitmap: Bitmap, quality: ProcessingQuality): Bitmap {
        Timber.d("Pre-processing image: ${bitmap.width}x${bitmap.height}, quality=$quality")
        
        // Resize if needed based on quality setting
        val resized = when (quality) {
            ProcessingQuality.FAST -> {
                // Max 1920px on long edge
                resizeIfNeeded(bitmap, 1920)
            }
            ProcessingQuality.BALANCED -> {
                // Max 2560px on long edge
                resizeIfNeeded(bitmap, 2560)
            }
            ProcessingQuality.HIGH -> {
                // Keep original or max 4096px
                resizeIfNeeded(bitmap, 4096)
            }
        }
        
        // Normalize color space
        return normalizeColorSpace(resized)
    }

    private fun resizeIfNeeded(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val maxCurrentDimension = maxOf(bitmap.width, bitmap.height)
        
        if (maxCurrentDimension <= maxDimension) {
            return bitmap.copy(Bitmap.Config.ARGB_8888, true)
        }
        
        val scale = maxDimension.toFloat() / maxCurrentDimension
        val newWidth = (bitmap.width * scale).toInt()
        val newHeight = (bitmap.height * scale).toInt()
        
        Timber.d("Resizing from ${bitmap.width}x${bitmap.height} to ${newWidth}x${newHeight}")
        
        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
    }

    private fun normalizeColorSpace(bitmap: Bitmap): Bitmap {
        // Ensure consistent color space and bit depth
        return if (bitmap.config != Bitmap.Config.ARGB_8888) {
            bitmap.copy(Bitmap.Config.ARGB_8888, true)
        } else {
            bitmap
        }
    }
}

/**
 * Image Post-processor
 * Final adjustments after AI processing
 */
@Singleton
class ImagePostProcessor @Inject constructor() {

    fun process(bitmap: Bitmap, config: AIProcessingConfig): Bitmap {
        Timber.d("Post-processing image")
        
        var result = bitmap
        
        // Apply tone mapping
        result = applyToneMapping(result)
        
        // Apply final contrast curve
        result = applyContrastCurve(result)
        
        // Final subtle sharpening
        result = applyFinalSharpening(result)
        
        return result
    }

    private fun applyToneMapping(bitmap: Bitmap): Bitmap {
        // Simple S-curve for better contrast
        val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        
        for (y in 0 until output.height) {
            for (x in 0 until output.width) {
                val pixel = output.getPixel(x, y)
                
                val a = (pixel shr 24) and 0xFF
                val r = applySCurve((pixel shr 16) and 0xFF)
                val g = applySCurve((pixel shr 8) and 0xFF)
                val b = applySCurve(pixel and 0xFF)
                
                output.setPixel(x, y, (a shl 24) or (r shl 16) or (g shl 8) or b)
            }
        }
        
        return output
    }

    private fun applySCurve(value: Int): Int {
        // S-curve formula for better midtones
        val normalized = value / 255f
        val curved = Math.pow(normalized.toDouble(), 0.9).toFloat()
        return (curved * 255).toInt().coerceIn(0, 255)
    }

    private fun applyContrastCurve(bitmap: Bitmap): Bitmap {
        val cm = ColorMatrix()
        cm.set(floatArrayOf(
            1.05f, 0f, 0f, 0f, -5f,
            0f, 1.05f, 0f, 0f, -5f,
            0f, 0f, 1.05f, 0f, -5f,
            0f, 0f, 0f, 1f, 0f
        ))
        
        return applyColorMatrix(bitmap, cm)
    }

    private fun applyFinalSharpening(bitmap: Bitmap): Bitmap {
        // Very subtle final sharpening
        return ImageAdjustments.applySharpen(bitmap, 0.1f)
    }

    private fun applyColorMatrix(bitmap: Bitmap, colorMatrix: ColorMatrix): Bitmap {
        val output = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint()
        paint.colorFilter = ColorMatrixColorFilter(colorMatrix)
        canvas.drawBitmap(bitmap, 0f, 0f, paint)
        return output
    }
}
