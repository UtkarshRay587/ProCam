package com.procam.app.data.local.dao

import androidx.room.*
import com.procam.app.data.local.entity.ImageEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for Images
 */
@Dao
interface ImageDao {

    @Query("SELECT * FROM images ORDER BY dateTaken DESC")
    fun getAllImages(): Flow<List<ImageEntity>>

    @Query("SELECT * FROM images WHERE id = :id")
    suspend fun getImageById(id: Long): ImageEntity?

    @Query("SELECT * FROM images WHERE filePath = :path")
    suspend fun getImageByPath(path: String): ImageEntity?

    @Query("SELECT * FROM images WHERE isProcessed = 1 ORDER BY dateTaken DESC")
    fun getProcessedImages(): Flow<List<ImageEntity>>

    @Query("SELECT * FROM images WHERE hasOriginal = 1 ORDER BY dateTaken DESC")
    fun getImagesWithOriginals(): Flow<List<ImageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertImage(image: ImageEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertImages(images: List<ImageEntity>)

    @Update
    suspend fun updateImage(image: ImageEntity)

    @Delete
    suspend fun deleteImage(image: ImageEntity)

    @Query("DELETE FROM images WHERE id = :id")
    suspend fun deleteImageById(id: Long)

    @Query("DELETE FROM images")
    suspend fun deleteAllImages()

    @Query("SELECT COUNT(*) FROM images")
    suspend fun getImageCount(): Int

    @Query("SELECT SUM(size) FROM images")
    suspend fun getTotalSize(): Long?
}

/**
 * Room Database
 */
package com.procam.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.procam.app.data.local.dao.ImageDao
import com.procam.app.data.local.entity.Converters
import com.procam.app.data.local.entity.ImageEntity

@Database(
    entities = [ImageEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class ProCamDatabase : RoomDatabase() {

    abstract fun imageDao(): ImageDao

    companion object {
        @Volatile
        private var INSTANCE: ProCamDatabase? = null

        fun getDatabase(context: Context): ProCamDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ProCamDatabase::class.java,
                    "procam_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
