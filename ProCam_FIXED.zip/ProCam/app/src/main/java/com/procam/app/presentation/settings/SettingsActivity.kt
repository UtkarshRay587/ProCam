package com.procam.app.presentation.settings

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.procam.app.R
import com.procam.app.databinding.ActivitySettingsBinding
import com.procam.app.domain.model.ProcessingQuality
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupViews()
        observeViewModel()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Settings"
    }

    private fun setupViews() {
        // Auto AI Enhancement
        binding.autoEnhanceSwitch.setOnCheckedChangeListener { _, isChecked ->
            viewModel.setAutoEnhanceEnabled(isChecked)
        }

        // Denoise Strength
        binding.denoiseSlider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) {
                binding.denoiseValue.text = "${value.toInt()}%"
                viewModel.setDenoiseStrength(value.toInt())
            }
        }

        // Sharpen Strength
        binding.sharpenSlider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) {
                binding.sharpenValue.text = "${value.toInt()}%"
                viewModel.setSharpenStrength(value.toInt())
            }
        }

        // Preserve Skin
        binding.preserveSkinSwitch.setOnCheckedChangeListener { _, isChecked ->
            viewModel.setPreserveSkin(isChecked)
        }

        // Preserve Texture
        binding.preserveTextureSwitch.setOnCheckedChangeListener { _, isChecked ->
            viewModel.setPreserveTexture(isChecked)
        }

        // Processing Quality
        binding.processingQualityGroup.setOnCheckedChangeListener { _, checkedId ->
            val quality = when (checkedId) {
                R.id.qualityFast -> ProcessingQuality.FAST
                R.id.qualityBalanced -> ProcessingQuality.BALANCED
                R.id.qualityHigh -> ProcessingQuality.HIGH
                else -> ProcessingQuality.BALANCED
            }
            viewModel.setProcessingQuality(quality)
        }

        // Save Original
        binding.saveOriginalSwitch.setOnCheckedChangeListener { _, isChecked ->
            viewModel.setSaveOriginal(isChecked)
        }

        // Auto Export
        binding.autoExportSwitch.setOnCheckedChangeListener { _, isChecked ->
            viewModel.setAutoExport(isChecked)
        }

        // Reset to Defaults
        binding.resetButton.setOnClickListener {
            showResetConfirmation()
        }

        // Privacy Policy
        binding.privacyPolicyButton.setOnClickListener {
            showPrivacyPolicy()
        }

        // About
        binding.aboutButton.setOnClickListener {
            showAbout()
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.config.collect { config ->
                // Update UI with current config
                binding.autoEnhanceSwitch.isChecked = config.autoEnhance
                binding.denoiseSlider.value = config.denoiseStrength.toFloat()
                binding.denoiseValue.text = "${config.denoiseStrength}%"
                binding.sharpenSlider.value = config.sharpenStrength.toFloat()
                binding.sharpenValue.text = "${config.sharpenStrength}%"
                binding.preserveSkinSwitch.isChecked = config.preserveSkin
                binding.preserveTextureSwitch.isChecked = config.preserveTexture
                binding.saveOriginalSwitch.isChecked = config.saveOriginal

                when (config.processingQuality) {
                    ProcessingQuality.FAST -> binding.qualityFast.isChecked = true
                    ProcessingQuality.BALANCED -> binding.qualityBalanced.isChecked = true
                    ProcessingQuality.HIGH -> binding.qualityHigh.isChecked = true
                }
            }
        }
    }

    private fun showResetConfirmation() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Reset Settings")
            .setMessage("Reset all settings to default values?")
            .setPositiveButton("Reset") { _, _ ->
                viewModel.resetToDefaults()
                Toast.makeText(this, "Settings reset to defaults", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showPrivacyPolicy() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Privacy Policy")
            .setMessage(
                "ProCam Privacy Commitment:\n\n" +
                "• 100% Offline Processing: All AI enhancement happens on your device\n" +
                "• No Data Collection: We don't collect any personal data\n" +
                "• No Analytics: We don't track your usage\n" +
                "• No Cloud Uploads: Your photos never leave your device\n" +
                "• No Watermarks: Your photos are yours, period\n" +
                "• Open Source: Code is available for review\n\n" +
                "ProCam is built with privacy as the foundation, not an afterthought."
            )
            .setPositiveButton("Close", null)
            .show()
    }

    private fun showAbout() {
        MaterialAlertDialogBuilder(this)
            .setTitle("About ProCam")
            .setMessage(
                "ProCam v0.1\n\n" +
                "Professional AI Camera & Editor\n\n" +
                "Features:\n" +
                "• Automatic AI enhancement on capture\n" +
                "• Advanced AI editing tools\n" +
                "• Background removal\n" +
                "• Super resolution\n" +
                "• 100% free, no ads, no watermarks\n\n" +
                "Made with ❤️ for privacy-conscious photographers"
            )
            .setPositiveButton("Close", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
