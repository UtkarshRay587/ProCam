package com.procam.app.domain.model

import android.graphics.Bitmap
import java.io.File
import java.util.Date

/**
 * Core domain entities for ProCam
 */

/**
 * Represents an image in ProCam Gallery
 */
data class ProCamImage(
    val id: Long = 0,
    val filePath: String,
    val fileName: String,
    val dateTaken: Date,
    val dateModified: Date,
    val width: Int,
    val height: Int,
    val size: Long, // in bytes
    val isProcessed: Boolean = false,
    val hasOriginal: Boolean = false,
    val originalPath: String? = null,
    val metadata: ImageMetadata? = null
) {
    val file: File get() = File(filePath)
    val aspectRatio: Float get() = width.toFloat() / height.toFloat()
}

/**
 * Image metadata preserved from EXIF
 */
data class ImageMetadata(
    val cameraMake: String? = null,
    val cameraModel: String? = null,
    val iso: Int? = null,
    val exposureTime: String? = null,
    val fNumber: String? = null,
    val focalLength: String? = null,
    val location: Location? = null
)

data class Location(
    val latitude: Double,
    val longitude: Double
)

/**
 * AI Processing configuration
 */
data class AIProcessingConfig(
    val autoEnhance: Boolean = true,
    val denoiseStrength: Int = 50, // 0-100
    val sharpenStrength: Int = 50,
    val preserveSkin: Boolean = true,
    val preserveTexture: Boolean = true,
    val processingQuality: ProcessingQuality = ProcessingQuality.BALANCED,
    val saveOriginal: Boolean = false
)

enum class ProcessingQuality {
    FAST,      // Lower resolution, faster processing
    BALANCED,  // Medium quality/speed
    HIGH       // Full resolution, slower but best quality
}

/**
 * Editing session state
 */
data class EditingSession(
    val sourceImage: ProCamImage,
    val currentBitmap: Bitmap? = null,
    val editHistory: List<EditOperation> = emptyList(),
    val canUndo: Boolean = false,
    val canRedo: Boolean = false
)

/**
 * Individual edit operation
 */
sealed class EditOperation {
    data class AIAutoEnhance(val strength: Int) : EditOperation()
    data class AIDenoise(val strength: Int) : EditOperation()
    data class AISharpen(val strength: Int) : EditOperation()
    data class AISuperResolution(val scale: Float = 2f) : EditOperation()
    data class AILowLightBoost(val strength: Int) : EditOperation()
    data class AIDetailRecovery(val strength: Int) : EditOperation()
    data class AIBackgroundRemoval(val keepTransparent: Boolean = true) : EditOperation()
    data class AIObjectRemoval(val maskPath: String) : EditOperation()
    
    data class Brightness(val value: Int) : EditOperation() // -100 to 100
    data class Contrast(val value: Int) : EditOperation()
    data class Highlights(val value: Int) : EditOperation()
    data class Shadows(val value: Int) : EditOperation()
    data class Saturation(val value: Int) : EditOperation()
    data class Temperature(val value: Int) : EditOperation()
    data class Tint(val value: Int) : EditOperation()
    data class Clarity(val value: Int) : EditOperation()
}

/**
 * Processing result
 */
sealed class ProcessingResult {
    data class Success(
        val outputPath: String,
        val processingTime: Long,
        val operations: List<EditOperation>
    ) : ProcessingResult()
    
    data class Error(
        val message: String,
        val exception: Exception? = null
    ) : ProcessingResult()
    
    data class Progress(
        val percentage: Int,
        val currentOperation: String
    ) : ProcessingResult()
}

/**
 * Camera capture configuration
 */
data class CameraConfig(
    val flashMode: FlashMode = FlashMode.AUTO,
    val hdrEnabled: Boolean = true,
    val resolution: CameraResolution = CameraResolution.HIGH,
    val autoAIEnabled: Boolean = true
)

enum class FlashMode {
    OFF, ON, AUTO
}

enum class CameraResolution {
    LOW,    // 1280x720
    MEDIUM, // 1920x1080
    HIGH,   // 3840x2160 or max
}

/**
 * Gallery filter and sort options
 */
data class GalleryFilter(
    val sortBy: SortBy = SortBy.DATE_DESC,
    val showProcessedOnly: Boolean = false
)

enum class SortBy {
    DATE_DESC,
    DATE_ASC,
    NAME_ASC,
    NAME_DESC,
    SIZE_DESC,
    SIZE_ASC
}
