package com.procam.app.data.repository

import android.content.Context
import android.graphics.Bitmap
import androidx.exifinterface.media.ExifInterface
import com.procam.app.data.local.dao.ImageDao
import com.procam.app.data.local.entity.ImageEntity
import com.procam.app.domain.model.ImageMetadata
import com.procam.app.domain.model.Location
import com.procam.app.domain.model.ProCamImage
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ImageRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val imageDao: ImageDao
) {

    private val galleryDir: File by lazy {
        File(context.getExternalFilesDir(null), "ProCam/Gallery").apply {
            mkdirs()
        }
    }

    private val originalsDir: File by lazy {
        File(context.getExternalFilesDir(null), "ProCam/Originals").apply {
            mkdirs()
        }
    }

    /**
     * Get all images from database
     */
    fun getAllImages(): Flow<List<ProCamImage>> {
        return imageDao.getAllImages().map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Get single image by ID
     */
    suspend fun getImageById(id: Long): ProCamImage? {
        return withContext(Dispatchers.IO) {
            imageDao.getImageById(id)?.toDomainModel()
        }
    }

    /**
     * Save a new image (from camera or import)
     * @param bitmap The processed/enhanced bitmap
     * @param saveOriginal Whether to save the original unprocessed version
     * @param originalBitmap The original unprocessed bitmap (if saveOriginal is true)
     */
    suspend fun saveImage(
        bitmap: Bitmap,
        saveOriginal: Boolean = false,
        originalBitmap: Bitmap? = null
    ): String = withContext(Dispatchers.IO) {
        try {
            // Generate filename
            val timestamp = System.currentTimeMillis()
            val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
            val dateString = dateFormat.format(Date(timestamp))
            val fileName = "PROCAM_$dateString.jpg"
            
            // Save main image
            val imageFile = File(galleryDir, fileName)
            saveBitmapToFile(bitmap, imageFile, 95)
            
            // Save original if requested
            var originalPath: String? = null
            if (saveOriginal && originalBitmap != null) {
                val originalFile = File(originalsDir, "ORIGINAL_$fileName")
                saveBitmapToFile(originalBitmap, originalFile, 100)
                originalPath = originalFile.absolutePath
            }
            
            // Extract metadata
            val metadata = extractMetadata(imageFile.absolutePath)
            
            // Save to database
            val entity = ImageEntity(
                filePath = imageFile.absolutePath,
                fileName = fileName,
                dateTaken = Date(timestamp),
                dateModified = Date(timestamp),
                width = bitmap.width,
                height = bitmap.height,
                size = imageFile.length(),
                isProcessed = true,
                hasOriginal = saveOriginal,
                originalPath = originalPath,
                metadata = metadata
            )
            
            imageDao.insertImage(entity)
            
            Timber.d("Image saved: ${imageFile.absolutePath}")
            imageFile.absolutePath
            
        } catch (e: Exception) {
            Timber.e(e, "Failed to save image")
            throw e
        }
    }

    /**
     * Update an existing image (replace)
     */
    suspend fun updateImage(path: String, bitmap: Bitmap) = withContext(Dispatchers.IO) {
        try {
            val file = File(path)
            if (!file.exists()) {
                throw IllegalArgumentException("Image file not found: $path")
            }
            
            // Save bitmap over existing file
            saveBitmapToFile(bitmap, file, 95)
            
            // Update database
            val entity = imageDao.getImageByPath(path)
            if (entity != null) {
                val updated = entity.copy(
                    dateModified = Date(),
                    width = bitmap.width,
                    height = bitmap.height,
                    size = file.length(),
                    isProcessed = true
                )
                imageDao.updateImage(updated)
            }
            
            Timber.d("Image updated: $path")
            
        } catch (e: Exception) {
            Timber.e(e, "Failed to update image")
            throw e
        }
    }

    /**
     * Save as a new copy
     */
    suspend fun saveImageCopy(bitmap: Bitmap, originalPath: String): String = withContext(Dispatchers.IO) {
        try {
            // Generate new filename
            val originalFile = File(originalPath)
            val baseName = originalFile.nameWithoutExtension
            val timestamp = System.currentTimeMillis()
            val fileName = "${baseName}_edit_$timestamp.jpg"
            
            val newFile = File(galleryDir, fileName)
            saveBitmapToFile(bitmap, newFile, 95)
            
            // Save to database
            val metadata = extractMetadata(newFile.absolutePath)
            val entity = ImageEntity(
                filePath = newFile.absolutePath,
                fileName = fileName,
                dateTaken = Date(),
                dateModified = Date(),
                width = bitmap.width,
                height = bitmap.height,
                size = newFile.length(),
                isProcessed = true,
                hasOriginal = false,
                originalPath = null,
                metadata = metadata
            )
            
            imageDao.insertImage(entity)
            
            Timber.d("Image copy saved: ${newFile.absolutePath}")
            newFile.absolutePath
            
        } catch (e: Exception) {
            Timber.e(e, "Failed to save image copy")
            throw e
        }
    }

    /**
     * Delete an image
     */
    suspend fun deleteImage(imageId: Long) = withContext(Dispatchers.IO) {
        try {
            val entity = imageDao.getImageById(imageId)
            if (entity != null) {
                // Delete files
                File(entity.filePath).delete()
                entity.originalPath?.let { File(it).delete() }
                
                // Delete from database
                imageDao.deleteImage(entity)
                
                Timber.d("Image deleted: ${entity.filePath}")
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to delete image")
            throw e
        }
    }

    /**
     * Delete multiple images
     */
    suspend fun deleteImages(imageIds: List<Long>) = withContext(Dispatchers.IO) {
        imageIds.forEach { deleteImage(it) }
    }

    /**
     * Export image to system gallery
     */
    suspend fun exportToGallery(imageId: Long): String = withContext(Dispatchers.IO) {
        // TODO: Implement MediaStore export
        ""
    }

    // Helper functions

    private fun saveBitmapToFile(bitmap: Bitmap, file: File, quality: Int) {
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
        }
    }

    private fun extractMetadata(path: String): ImageMetadata? {
        return try {
            val exif = ExifInterface(path)
            
            val make = exif.getAttribute(ExifInterface.TAG_MAKE)
            val model = exif.getAttribute(ExifInterface.TAG_MODEL)
            val iso = exif.getAttribute(ExifInterface.TAG_ISO_SPEED)?.toIntOrNull()
            val exposureTime = exif.getAttribute(ExifInterface.TAG_EXPOSURE_TIME)
            val fNumber = exif.getAttribute(ExifInterface.TAG_F_NUMBER)
            val focalLength = exif.getAttribute(ExifInterface.TAG_FOCAL_LENGTH)
            
            val latLong = FloatArray(2)
            val hasLocation = exif.getLatLong(latLong)
            val location = if (hasLocation) {
                Location(latLong[0].toDouble(), latLong[1].toDouble())
            } else null
            
            ImageMetadata(
                cameraMake = make,
                cameraModel = model,
                iso = iso,
                exposureTime = exposureTime,
                fNumber = fNumber,
                focalLength = focalLength,
                location = location
            )
        } catch (e: Exception) {
            Timber.w(e, "Failed to extract metadata")
            null
        }
    }

    /**
     * Clean up temp files
     */
    suspend fun cleanupTempFiles() = withContext(Dispatchers.IO) {
        val tempDir = File(context.externalCacheDir, "ProCam/Temp")
        tempDir.listFiles()?.forEach { it.delete() }
    }
}
