package com.procam.app.ai.processors

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Image Adjustments Utilities
 * Low-level image manipulation functions
 */
object ImageAdjustments {

    /**
     * Adjust brightness
     * @param value -1.0 to 1.0
     */
    fun adjustBrightness(bitmap: Bitmap, value: Float): Bitmap {
        val cm = ColorMatrix()
        val brightness = value * 255
        cm.set(floatArrayOf(
            1f, 0f, 0f, 0f, brightness,
            0f, 1f, 0f, 0f, brightness,
            0f, 0f, 1f, 0f, brightness,
            0f, 0f, 0f, 1f, 0f
        ))
        return applyColorMatrix(bitmap, cm)
    }

    /**
     * Adjust contrast
     * @param value contrast multiplier (1.0 = no change)
     */
    fun adjustContrast(bitmap: Bitmap, value: Float): Bitmap {
        val translate = (1f - value) / 2f * 255f
        val cm = ColorMatrix()
        cm.set(floatArrayOf(
            value, 0f, 0f, 0f, translate,
            0f, value, 0f, 0f, translate,
            0f, 0f, value, 0f, translate,
            0f, 0f, 0f, 1f, 0f
        ))
        return applyColorMatrix(bitmap, cm)
    }

    /**
     * Adjust saturation
     * @param value saturation multiplier (1.0 = no change)
     */
    fun adjustSaturation(bitmap: Bitmap, value: Float): Bitmap {
        val cm = ColorMatrix()
        cm.setSaturation(value)
        return applyColorMatrix(bitmap, cm)
    }

    /**
     * Adjust temperature (warm/cool)
     * @param value -1.0 (cool) to 1.0 (warm)
     */
    fun adjustTemperature(bitmap: Bitmap, value: Float): Bitmap {
        val cm = ColorMatrix()
        if (value > 0) {
            // Warm: boost red, reduce blue
            cm.set(floatArrayOf(
                1f + value * 0.3f, 0f, 0f, 0f, 0f,
                0f, 1f, 0f, 0f, 0f,
                0f, 0f, 1f - value * 0.3f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            ))
        } else {
            // Cool: boost blue, reduce red
            val absValue = abs(value)
            cm.set(floatArrayOf(
                1f - absValue * 0.3f, 0f, 0f, 0f, 0f,
                0f, 1f, 0f, 0f, 0f,
                0f, 0f, 1f + absValue * 0.3f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            ))
        }
        return applyColorMatrix(bitmap, cm)
    }

    /**
     * Adjust tint (green/magenta)
     * @param value -1.0 (green) to 1.0 (magenta)
     */
    fun adjustTint(bitmap: Bitmap, value: Float): Bitmap {
        val cm = ColorMatrix()
        if (value > 0) {
            // Magenta: boost red and blue, reduce green
            cm.set(floatArrayOf(
                1f + value * 0.2f, 0f, 0f, 0f, 0f,
                0f, 1f - value * 0.2f, 0f, 0f, 0f,
                0f, 0f, 1f + value * 0.2f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            ))
        } else {
            // Green: boost green, reduce red and blue
            val absValue = abs(value)
            cm.set(floatArrayOf(
                1f - absValue * 0.2f, 0f, 0f, 0f, 0f,
                0f, 1f + absValue * 0.2f, 0f, 0f, 0f,
                0f, 0f, 1f - absValue * 0.2f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            ))
        }
        return applyColorMatrix(bitmap, cm)
    }

    /**
     * Adjust highlights
     * @param value -1.0 to 1.0
     */
    fun adjustHighlights(bitmap: Bitmap, value: Float): Bitmap {
        val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        
        for (y in 0 until output.height) {
            for (x in 0 until output.width) {
                val pixel = output.getPixel(x, y)
                
                val a = (pixel shr 24) and 0xFF
                val r = adjustHighlightChannel((pixel shr 16) and 0xFF, value)
                val g = adjustHighlightChannel((pixel shr 8) and 0xFF, value)
                val b = adjustHighlightChannel(pixel and 0xFF, value)
                
                output.setPixel(x, y, (a shl 24) or (r shl 16) or (g shl 8) or b)
            }
        }
        
        return output
    }

    private fun adjustHighlightChannel(channel: Int, value: Float): Int {
        // Only affect bright pixels (> 128)
        return if (channel > 128) {
            val factor = 1f + (value * (channel - 128) / 127f)
            (channel * factor).toInt().coerceIn(0, 255)
        } else {
            channel
        }
    }

    /**
     * Adjust shadows
     * @param value -1.0 to 1.0
     */
    fun adjustShadows(bitmap: Bitmap, value: Float): Bitmap {
        val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        
        for (y in 0 until output.height) {
            for (x in 0 until output.width) {
                val pixel = output.getPixel(x, y)
                
                val a = (pixel shr 24) and 0xFF
                val r = adjustShadowChannel((pixel shr 16) and 0xFF, value)
                val g = adjustShadowChannel((pixel shr 8) and 0xFF, value)
                val b = adjustShadowChannel(pixel and 0xFF, value)
                
                output.setPixel(x, y, (a shl 24) or (r shl 16) or (g shl 8) or b)
            }
        }
        
        return output
    }

    private fun adjustShadowChannel(channel: Int, value: Float): Int {
        // Only affect dark pixels (< 128)
        return if (channel < 128) {
            val factor = 1f + (value * (128 - channel) / 128f)
            (channel * factor).toInt().coerceIn(0, 255)
        } else {
            channel
        }
    }

    /**
     * Adjust clarity (mid-tone contrast)
     * @param value -1.0 to 1.0
     */
    fun adjustClarity(bitmap: Bitmap, value: Float): Bitmap {
        // Clarity = local contrast enhancement
        return unsharpMask(bitmap, value)
    }

    /**
     * Histogram equalization for better exposure
     */
    fun equalizeHistogram(bitmap: Bitmap): Bitmap {
        val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val histogram = IntArray(256)
        val cdf = IntArray(256)
        
        // Build histogram
        for (y in 0 until output.height) {
            for (x in 0 until output.width) {
                val pixel = output.getPixel(x, y)
                val luminance = getLuminance(pixel)
                histogram[luminance]++
            }
        }
        
        // Build CDF
        cdf[0] = histogram[0]
        for (i in 1 until 256) {
            cdf[i] = cdf[i - 1] + histogram[i]
        }
        
        // Normalize CDF
        val totalPixels = output.width * output.height
        val cdfMin = cdf.firstOrNull { it > 0 } ?: 0
        
        // Apply equalization
        for (y in 0 until output.height) {
            for (x in 0 until output.width) {
                val pixel = output.getPixel(x, y)
                val luminance = getLuminance(pixel)
                val newLuminance = ((cdf[luminance] - cdfMin).toFloat() / (totalPixels - cdfMin) * 255).toInt()
                
                val factor = newLuminance.toFloat() / luminance.coerceAtLeast(1)
                
                val a = (pixel shr 24) and 0xFF
                val r = ((pixel shr 16) and 0xFF * factor).toInt().coerceIn(0, 255)
                val g = ((pixel shr 8) and 0xFF * factor).toInt().coerceIn(0, 255)
                val b = (pixel and 0xFF * factor).toInt().coerceIn(0, 255)
                
                output.setPixel(x, y, (a shl 24) or (r shl 16) or (g shl 8) or b)
            }
        }
        
        return output
    }

    /**
     * Auto white balance
     */
    fun autoWhiteBalance(bitmap: Bitmap): Bitmap {
        var rSum = 0L
        var gSum = 0L
        var bSum = 0L
        val totalPixels = bitmap.width * bitmap.height
        
        // Calculate average RGB
        for (y in 0 until bitmap.height) {
            for (x in 0 until bitmap.width) {
                val pixel = bitmap.getPixel(x, y)
                rSum += (pixel shr 16) and 0xFF
                gSum += (pixel shr 8) and 0xFF
                bSum += pixel and 0xFF
            }
        }
        
        val rAvg = rSum / totalPixels
        val gAvg = gSum / totalPixels
        val bAvg = bSum / totalPixels
        
        val avgGray = (rAvg + gAvg + bAvg) / 3f
        
        val rScale = avgGray / rAvg
        val gScale = avgGray / gAvg
        val bScale = avgGray / bAvg
        
        val cm = ColorMatrix()
        cm.set(floatArrayOf(
            rScale, 0f, 0f, 0f, 0f,
            0f, gScale, 0f, 0f, 0f,
            0f, 0f, bScale, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        ))
        
        return applyColorMatrix(bitmap, cm)
    }

    /**
     * Bilateral filter for edge-preserving smoothing
     */
    fun bilateralFilter(bitmap: Bitmap, strength: Float, preserveTexture: Boolean): Bitmap {
        // Simplified bilateral filter
        val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val radius = (strength * 5).toInt().coerceIn(1, 10)
        val sigmaColor = 50f * strength
        val sigmaSpace = 50f * strength
        
        // Simple box blur as approximation for performance
        return gaussianBlur(bitmap, radius)
    }

    /**
     * Sharpen image
     */
    fun applySharpen(bitmap: Bitmap, strength: Float): Bitmap {
        val kernel = floatArrayOf(
            0f, -strength, 0f,
            -strength, 1f + 4f * strength, -strength,
            0f, -strength, 0f
        )
        return applyConvolution(bitmap, kernel, 3)
    }

    /**
     * Unsharp mask for detail enhancement
     */
    fun unsharpMask(bitmap: Bitmap, strength: Float): Bitmap {
        val blurred = gaussianBlur(bitmap, 2)
        val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        
        for (y in 0 until output.height) {
            for (x in 0 until output.width) {
                val original = output.getPixel(x, y)
                val blur = blurred.getPixel(x, y)
                
                val a = (original shr 24) and 0xFF
                val r = unsharpChannel((original shr 16) and 0xFF, (blur shr 16) and 0xFF, strength)
                val g = unsharpChannel((original shr 8) and 0xFF, (blur shr 8) and 0xFF, strength)
                val b = unsharpChannel(original and 0xFF, blur and 0xFF, strength)
                
                output.setPixel(x, y, (a shl 24) or (r shl 16) or (g shl 8) or b)
            }
        }
        
        return output
    }

    private fun unsharpChannel(original: Int, blurred: Int, strength: Float): Int {
        val diff = original - blurred
        return (original + diff * strength).toInt().coerceIn(0, 255)
    }

    /**
     * Simple background removal (placeholder)
     */
    fun simpleBackgroundRemoval(bitmap: Bitmap, transparent: Boolean): Bitmap {
        // TODO: Implement actual segmentation
        // For now, return copy with alpha channel
        return bitmap.copy(Bitmap.Config.ARGB_8888, true)
    }

    // Helper functions

    private fun applyColorMatrix(bitmap: Bitmap, colorMatrix: ColorMatrix): Bitmap {
        val output = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint()
        paint.colorFilter = ColorMatrixColorFilter(colorMatrix)
        canvas.drawBitmap(bitmap, 0f, 0f, paint)
        return output
    }

    private fun applyConvolution(bitmap: Bitmap, kernel: FloatArray, kernelSize: Int): Bitmap {
        val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val offset = kernelSize / 2
        
        for (y in offset until bitmap.height - offset) {
            for (x in offset until bitmap.width - offset) {
                var r = 0f
                var g = 0f
                var b = 0f
                
                var kernelIndex = 0
                for (ky in -offset..offset) {
                    for (kx in -offset..offset) {
                        val pixel = bitmap.getPixel(x + kx, y + ky)
                        val weight = kernel[kernelIndex++]
                        r += ((pixel shr 16) and 0xFF) * weight
                        g += ((pixel shr 8) and 0xFF) * weight
                        b += (pixel and 0xFF) * weight
                    }
                }
                
                val a = (bitmap.getPixel(x, y) shr 24) and 0xFF
                output.setPixel(x, y, 
                    (a shl 24) or 
                    (r.toInt().coerceIn(0, 255) shl 16) or 
                    (g.toInt().coerceIn(0, 255) shl 8) or 
                    b.toInt().coerceIn(0, 255)
                )
            }
        }
        
        return output
    }

    private fun gaussianBlur(bitmap: Bitmap, radius: Int): Bitmap {
        // Simple box blur approximation
        var output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        
        // Horizontal pass
        output = boxBlurHorizontal(output, radius)
        
        // Vertical pass
        output = boxBlurVertical(output, radius)
        
        return output
    }

    private fun boxBlurHorizontal(bitmap: Bitmap, radius: Int): Bitmap {
        val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        
        for (y in 0 until bitmap.height) {
            for (x in 0 until bitmap.width) {
                var r = 0
                var g = 0
                var b = 0
                var count = 0
                
                for (dx in -radius..radius) {
                    val nx = (x + dx).coerceIn(0, bitmap.width - 1)
                    val pixel = bitmap.getPixel(nx, y)
                    r += (pixel shr 16) and 0xFF
                    g += (pixel shr 8) and 0xFF
                    b += pixel and 0xFF
                    count++
                }
                
                val a = (bitmap.getPixel(x, y) shr 24) and 0xFF
                output.setPixel(x, y, 
                    (a shl 24) or 
                    ((r / count) shl 16) or 
                    ((g / count) shl 8) or 
                    (b / count)
                )
            }
        }
        
        return output
    }

    private fun boxBlurVertical(bitmap: Bitmap, radius: Int): Bitmap {
        val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        
        for (x in 0 until bitmap.width) {
            for (y in 0 until bitmap.height) {
                var r = 0
                var g = 0
                var b = 0
                var count = 0
                
                for (dy in -radius..radius) {
                    val ny = (y + dy).coerceIn(0, bitmap.height - 1)
                    val pixel = bitmap.getPixel(x, ny)
                    r += (pixel shr 16) and 0xFF
                    g += (pixel shr 8) and 0xFF
                    b += pixel and 0xFF
                    count++
                }
                
                val a = (bitmap.getPixel(x, y) shr 24) and 0xFF
                output.setPixel(x, y, 
                    (a shl 24) or 
                    ((r / count) shl 16) or 
                    ((g / count) shl 8) or 
                    (b / count)
                )
            }
        }
        
        return output
    }

    private fun getLuminance(pixel: Int): Int {
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF
        return (0.299 * r + 0.587 * g + 0.114 * b).toInt()
    }
}
